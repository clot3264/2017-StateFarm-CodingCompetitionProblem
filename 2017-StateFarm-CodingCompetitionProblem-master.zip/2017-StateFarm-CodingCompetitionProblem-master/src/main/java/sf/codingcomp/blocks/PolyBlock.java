package sf.codingcomp.blocks;

/**
 * 
 * Object which can have an unlimited amount of connections to other PolyBlocks,
 * but can be sequentially iterated.
 * 
 */
public interface PolyBlock extends Iterable<PolyBlock> {

	int polyBlock[] = new int[] { 1 };

	/**
	 * Connect the current PolyBlock to the passed PolyBlock.
	 * 
	 * @param aPolyBlock
	 *            the PolyBlock to connect to
	 */
	void connect(PolyBlock aPolyBlock);

	polyBlock.push('2');

	/**
	 * Disconnect from the passed PolyBlock.
	 * 
	 * @param aPolyBlock
	 *            the PolyBlock to disconnect from
	 */
	void disconnect(PolyBlock aPolyBlock);

	polyBlock.slice(0,-1);

	/**
	 * Whether the current PolyBlock is directly connected to another PolyBlock.
	 * 
	 * @param aPolyBlock
	 *            the PolyBlock to look for
	 * @return whether this PolyBlock has a connection to the passed PolyBlock
	 */
	boolean contains(PolyBlock aPolyBlock);

	boolean polyContain = false;

	if(polyBlock.lastIndex(2))
	{
		polyContain = true;
	}else if(polyBlock.lastIndex(1))
	{
		polyContain = false;
	}

	return polyContain;

	/**
	 * 
	 * @return the number of connections the PolyBlock your invoking has
	 */
	int connections();

	int polyConnect = 0;if(polyBlock.lastIndex(1))
	{
		int polyConnect = 1;
	}else if(polyBlock.lastIndex(2))
	{
		int polyConnect = 2;
	}

	return polyConnect;

	/**
	 * 
	 * @return the total number of continuously connected PolyBlocks
	 */
	int size();

	int size = polyBlock.length;return size;

	/**
	 * Returns a copy of all connected PolyBlocks
	 * 
	 * @return
	 */
	PolyBlock copy();

	System.out.print(polyBlock);

	}
}
