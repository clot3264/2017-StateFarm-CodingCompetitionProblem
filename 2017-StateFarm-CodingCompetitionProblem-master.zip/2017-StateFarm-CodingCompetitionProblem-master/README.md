# Welcome
Welcome to the 2017 State Farm Coding Competition!

# Instructions
Read the directions in '2017 Java Coding Competition Problem Statement.pdf'

# Submitting
Open a pull request against the StateFarmInsCodingCompetition/2017-StateFarm-CodingCompetitionProblem repository. Only one teammate needs to open a pull request.

# Dealing with new line characters
https://help.github.com/articles/dealing-with-line-endings/

# Questions?
E-mail codingcompetition@statefarm.com, or to post a public question or report a problem, open an issue.